import math
print(dir(math))
help(math.sqrt)
print(math.sqrt(9))

import os
help(os)
print(os.listdir())
print(dir(os))

print(math.log(100))
print(math.ceil(9.234))
print(math.floor(9.234))
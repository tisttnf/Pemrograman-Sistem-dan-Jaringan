import myfunction

# Contoh List
list = [4, 3, 5, 6, 7, 8, 9, 1, 3, 2]
print(f"List : {list}")
print(f"Nilai Maksimum : {myfunction.mymax(list)}")
print(f"Nilai Minimum : {myfunction.mymin(list)}")
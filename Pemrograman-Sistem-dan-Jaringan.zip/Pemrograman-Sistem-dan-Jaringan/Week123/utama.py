import hitung

pesan = "ini kode utama"
print(pesan)

x = float(input("Masukan nilai 1: "))
y = float(input("Masukan nilai 2: "))

hasil = hitung.tambah(x,y)

print("Hasil penjumlahan %f dan %f adalah %f" %(x,y,hasil))
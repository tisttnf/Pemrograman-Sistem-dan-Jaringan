# Tugas

- cat servers.txt
```
https://www.detik.com
https://www.nurulfikri.ac.id
https://www.ui.ac.id
https://www.kompas.com
https://www.motogp.com
```
- Gunakan multi threading konsep untuk melakukan pemantuan dalam servers.txt yang kemudian di cetak pada command line seperti file cekweb.py
- Bandingkan dengan tanpa menggunakan multi threading
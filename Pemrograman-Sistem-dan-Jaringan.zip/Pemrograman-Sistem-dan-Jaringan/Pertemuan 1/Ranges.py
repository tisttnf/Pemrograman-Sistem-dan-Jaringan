# range(i) [0, 1, ..., n-1]
# range(i, j) [i, i+1, ..., j-1]
# range(i, j, k) [i, i+k, ..., m]
print(range(5, 25, 3))
a = 2000
pesan = "Harga rata rata adalah Rp."
# print(pesan + a) # Error
print(pesan + str(a))

x = 2
y = 45
z = y / x
r = float(y) / x
s = float(y) / float(x)
b = "2"
c = 6
# e = b + c # Error
f = int(b) + c
print(z)
print(r)
print(s)
print(f)
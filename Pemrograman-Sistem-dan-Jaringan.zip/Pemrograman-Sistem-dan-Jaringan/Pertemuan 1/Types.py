x = 1
print(type(x))
print(isinstance(x, int))
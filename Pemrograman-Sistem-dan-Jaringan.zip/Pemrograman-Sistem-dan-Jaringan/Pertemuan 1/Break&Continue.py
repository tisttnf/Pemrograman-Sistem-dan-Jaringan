for i in range(5) :
    print(i)
    if i < 3 :
        continue
    break
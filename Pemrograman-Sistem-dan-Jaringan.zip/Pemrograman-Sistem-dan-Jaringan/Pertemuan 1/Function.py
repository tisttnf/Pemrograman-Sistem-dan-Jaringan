def cetak(data) :
    print(data)

def tambah(x, y) :
    r = x + y
    return r

cetak("hello world")
print(tambah(2, 4))
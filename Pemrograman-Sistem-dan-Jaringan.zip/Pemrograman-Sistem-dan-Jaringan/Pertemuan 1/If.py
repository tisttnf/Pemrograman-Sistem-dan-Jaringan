a = 1

if a == 0 :
    print("a is 0")
elif a == 1 :
    print("a is 1")
else :
    print("a is something else")

if 5 :
    print("hello")

if "hello" :
    print(5)
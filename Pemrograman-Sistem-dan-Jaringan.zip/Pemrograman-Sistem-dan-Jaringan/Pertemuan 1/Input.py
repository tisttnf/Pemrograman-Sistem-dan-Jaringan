# Error
# nama = raw_input("Masukkan nama Anda: ")
# type(nama)
# print(nama)

nilai = input("Masukkan nilai: ")
type(nilai)
print(nilai)
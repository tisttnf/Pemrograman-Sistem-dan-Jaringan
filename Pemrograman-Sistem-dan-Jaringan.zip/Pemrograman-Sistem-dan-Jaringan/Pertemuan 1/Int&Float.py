print(5 / 2)
print(5 / 2.)
print(float(5) / 2)
print(int(5.2))
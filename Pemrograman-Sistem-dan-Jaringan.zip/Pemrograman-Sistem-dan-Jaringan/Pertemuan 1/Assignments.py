a = b = 0
a, b = 3, 5
a, b = b, a
print(a)
print(b)
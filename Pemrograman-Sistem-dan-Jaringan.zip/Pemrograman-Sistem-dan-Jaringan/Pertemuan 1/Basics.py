print(1 + 1)
print("hello world")
x = 1
y = 2
print(x + y)
print(x)
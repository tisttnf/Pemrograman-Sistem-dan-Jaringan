import sys

arg0 = sys.argv[0]
# arg1 = sys.argv[1]

print("Argument 0 :" + arg0)
# print("Argument 1 :" + arg1)
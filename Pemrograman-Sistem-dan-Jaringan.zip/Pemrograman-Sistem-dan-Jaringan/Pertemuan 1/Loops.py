print(range(5))
for i in range(5) :
    print(i)
# Multicast

- Menggabungkan UDP Unicast dengan multicast
- Buatlah 3 program
    - 1 client sender
    - 
- Computer Y -> Computer X (UDP Unicast, Port: 20000)
- Computer X -> Computer A,C (UDP Multicast, Port: 10000)
- Computer B,D tidak menerima pesan
- Computer X (Server 20000, Client 10000)
- Computer A,C -> Server 10000